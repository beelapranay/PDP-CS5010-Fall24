package polynomial;
import java.util.Arrays;

public class SimplePolynomial implements Polynomial {

  private int[] coefficients;
  private String polynomial;

  public SimplePolynomial() {
    this.polynomial = "0";
    coefficients = new int[1];
  }

  @Override
  public Polynomial add(Polynomial other) {
    int maxDegree = Math.max(this.getDegree(), other.getDegree());

    if(coefficients.length <= maxDegree) {
      coefficients = Arrays.copyOf(coefficients, maxDegree);
    }

    for (int i = 0; i <= other.getDegree(); i++) {
      coefficients[i] += other.getCoefficient(i);
    }

    return this;
  }

  @Override
  public Polynomial multiply(Polynomial other) {
    Polynomial result = new SimplePolynomial();

    for(int i = 0; i <= this.getDegree(); i++) {
      for(int j = 0; j <= other.getDegree(); j++) {
        int power = i + j;
        int coefficient = this.coefficients[i] * other.getCoefficient(j);

        result.addTerm(coefficient, power);
      }
    }

    return result;
  }

  @Override
  public Polynomial derivative() {
    SimplePolynomial result = new SimplePolynomial();

    for (int i = 1; i < coefficients.length; i++) {
      result.addTerm(this.getCoefficient(i)*i, i-1);
    }

    return result;
  }


  @Override
  public void addTerm(int coefficient, int power) throws IllegalArgumentException {
    if(power < 0) {
      throw new IllegalArgumentException();
    }
    if(power > coefficients.length - 1) {
      coefficients = Arrays.copyOf(coefficients, power+1);
    }

    if(coefficients[power] == 0) {
      coefficients[power] = coefficient;
    } else {
      coefficients[power] += coefficient;
    }
  }

  @Override
  public int getDegree() {
    return coefficients.length - 1;
  }

  @Override
  public double evaluate(double x) {
    double result = 0.0;

    for(int i = 0; i < coefficients.length; i++) {
      result += coefficients[i] * Math.pow(x, i);
    }

    return result;
  }

  @Override
  public int getCoefficient(int power) {
    if(power > coefficients.length - 1) {
      return 0;
    }
    return coefficients[power];
  }

  @Override
  public String toString() {
    StringBuilder result = new StringBuilder();

    for(int i = coefficients.length - 1; i >= 0; i--) {
      int coefficient = coefficients[i];

      if(coefficient == 0) {
        continue;
      } if(result.length() > 0 && coefficient > 0) {
        result.append("+");
      } if(i == 0) {
        result.append(coefficient);
      } else {
        result.append(coefficient).append("x^").append(i);
      }
    }

    if(result.length() > 0) {
      this.polynomial = result.toString();
    } else {
      this.polynomial = "0";
    }

    return this.polynomial;
  }


}
