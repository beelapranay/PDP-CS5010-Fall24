package polynomial;

public class Terms {
  private int power;
  private int coefficient;

  public Terms(int coefficient, int power) {
    this.power = power;
    this.coefficient = coefficient;
  }

  public void setPower(int power) {
    this.power = power;
  }

  public void setCoefficient(int coefficient) {
    this.coefficient = coefficient;
  }

  public int getPower() {
    return this.power;
  }

  public int getCoefficient() {
    return this.coefficient;
  }
}
