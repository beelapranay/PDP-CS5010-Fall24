import org.junit.Test;
import polynomial.Polynomial;
import polynomial.SimplePolynomial;
import polynomial.SparsePolynomial;

import static org.junit.Assert.assertEquals;

public class SampleTest {

    @Test
    public void sampleTest() {
        int degree_a = 20000000;
        int degree_b = 30000000;
        Polynomial a = new SparsePolynomial();
        Polynomial b = new SimplePolynomial();

        a.addTerm(1,degree_a);
        a.addTerm(1,0);

        b.addTerm(2,degree_b);
        b.addTerm(1,0);

        Polynomial c = a.multiply(b);

        assertEquals("Coefficient does not match",2,c.getCoefficient(degree_a+degree_b));
        assertEquals("Coefficient does not match",2,c.getCoefficient(degree_b));
        assertEquals("Coefficient does not match",1,c.getCoefficient(degree_a));
        assertEquals("Coefficient does not match",1,c.getCoefficient(0));
    }

    @Test
    public void testSparsePolynomial() {
        int degree_a = 20000000;
        int degree_b = 3;
        Polynomial a = new SparsePolynomial();
        Polynomial b = new SimplePolynomial();

        //a.addTerm(3,2);
        a.addTerm(1,20000000);
        a.addTerm(2,3);
        a.addTerm(4,5);
        a.addTerm(6,7);

        b.addTerm(2,degree_b);
        b.addTerm(1,0);

        System.out.println(a.toString());
    }

    @Test
    public void testSparsePolynomialAdd() {
        Polynomial a = new SparsePolynomial();
        Polynomial b = new SparsePolynomial();

        a.addTerm(1,20000);
        a.addTerm(2,3);
        a.addTerm(4,5);
        a.addTerm(6,7);

        b.addTerm(2,3);
        b.addTerm(1,0);

        Polynomial result = a.add(b);

        System.out.println(result.toString());
    }
}
