import org.junit.Test;

import polynomial.Polynomial;
import polynomial.SimplePolynomial;
import polynomial.SparsePolynomial;

import static org.junit.Assert.assertEquals;

/**
 * This class contains sample unit tests for the Polynomial class,
 * demonstrating multiplication and addition operations on both
 * SimplePolynomial and SparsePolynomial types.
 */
public class SampleTest {

  /**
   * A sample test to verify the multiplication of two polynomials,
   * one of type SparsePolynomial and one of type SimplePolynomial.
   * <p>
   * The test verifies that the coefficients of the resulting polynomial
   * match the expected values after multiplication.
   */
  @Test
  public void sampleTest() {
    int degree_a = 20000000;
    int degree_b = 30000000;
    Polynomial a = new SparsePolynomial();
    Polynomial b = new SimplePolynomial();

    a.addTerm(1, degree_a);
    a.addTerm(1, 0);

    b.addTerm(2, degree_b);
    b.addTerm(1, 0);

    Polynomial c = a.multiply(b);

    assertEquals("Coefficient does not match", 2, c.getCoefficient(degree_a + degree_b));
    assertEquals("Coefficient does not match", 2, c.getCoefficient(degree_b));
    assertEquals("Coefficient does not match", 1, c.getCoefficient(degree_a));
    assertEquals("Coefficient does not match", 1, c.getCoefficient(0));
  }

  /**
   * A test that checks the proper construction of a SparsePolynomial and prints
   * its string representation after adding several terms.
   * This test demonstrates adding terms with large and small exponents and
   * visualizes the polynomial.
   */
  @Test
  public void testSparsePolynomial() {
    int degree_a = 20000000;
    int degree_b = 3;
    Polynomial a = new SparsePolynomial();
    Polynomial b = new SimplePolynomial();

    a.addTerm(1, degree_a);
    a.addTerm(2, 3);
    a.addTerm(4, 5);
    a.addTerm(6, 7);

    b.addTerm(2, degree_b);
    b.addTerm(1, 0);

    System.out.println(a.toString());
  }

  /**
   * A test that checks the addition of two SparsePolynomials and prints
   * the string representation of the result after adding the polynomials.
   * <p>
   * This test demonstrates adding two polynomials and verifies the final
   * polynomial structure.
   */
  @Test
  public void testSparsePolynomialAdd() {
    Polynomial a = new SparsePolynomial();
    Polynomial b = new SparsePolynomial();

    a.addTerm(1, 20000);
    a.addTerm(2, 3);
    a.addTerm(4, 5);
    a.addTerm(6, 7);

    b.addTerm(2, 3);
    b.addTerm(1, 0);

    Polynomial result = a.add(b);

    System.out.println(result.toString());
  }
}
