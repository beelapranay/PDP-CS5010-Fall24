import org.junit.Test;

import polynomial.Polynomial;
import polynomial.SimplePolynomial;
import polynomial.SparsePolynomial;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

/**
 * This class contains unit tests for verifying polynomial operations
 * (multiplication and string representation) using large values
 * in both SparsePolynomial and SimplePolynomial types.
 */
public class SimpleAndSparsePolynomialTest {

  /**
   * Tests the multiplication of two polynomials with large degrees
   * and verifies the resulting polynomial's string representation.
   * This test has a timeout of 5000ms to ensure it completes in a reasonable time.
   */
  @Test(timeout = 5000)
  public void testForLargeValues() {
    int degree_a = 20000000;
    int degree_b = 30000000;
    Polynomial a = new SparsePolynomial();
    Polynomial b = new SimplePolynomial();

    a.addTerm(1, degree_a);
    a.addTerm(1, 0);

    b.addTerm(2, degree_b);
    b.addTerm(1, 0);

    Polynomial c = a.multiply(b);

    System.out.println(c.toString());

    assertEquals("2x^50000000+2x^30000000+1x^20000000+1",
            c.toString());
  }

  /**
   * Tests the multiplication of two polynomials with large exponents and coefficients,
   * ensuring that the string representation of the resulting polynomial is correct.
   * This test has a timeout of 5000ms.
   */
  @Test(timeout = 5000)
  public void testForLargeValues1() {
    int degree_a = 20000;
    int degree_b = 300000000;
    Polynomial a = new SparsePolynomial();
    Polynomial b = new SimplePolynomial();

    a.addTerm(200000, degree_a);
    a.addTerm(-499, 0);

    b.addTerm(39909, degree_b);
    b.addTerm(576, 0);

    Polynomial c = a.multiply(b);

    assertEquals("-608134592x^300020000-19914591x^300000000+115200000x^20000-287424",
            c.toString());
  }

  /**
   * Tests the multiplication of polynomials with very large exponents and verifies
   * that the resulting polynomial is correctly represented as a string.
   * This test also has a timeout of 5000ms.
   */
  @Test(timeout = 5000)
  public void testForLargeValues2() {
    int degree_a = 200;
    int degree_b = 333333333;
    Polynomial a = new SparsePolynomial();
    Polynomial b = new SimplePolynomial();

    a.addTerm(100089, degree_a);
    a.addTerm(2, 0);

    b.addTerm(3445679, degree_b);
    b.addTerm(698, 0);

    Polynomial c = a.multiply(b);

    assertEquals("1277181751x^333333533+6891358x^333333333+69862122x^200+1396",
            c.toString());
  }

  /**
   * Tests the multiplication of polynomials where both polynomials
   * contain terms with large degrees and coefficients.
   * The test ensures that the resulting polynomial is correctly generated.
   * This test also has a timeout of 5000ms.
   */
  @Test(timeout = 5000)
  public void testForLargeValues3() {
    int degree_a = 2;
    int degree_b = 300000;
    Polynomial a = new SparsePolynomial();
    Polynomial b = new SimplePolynomial();

    a.addTerm(1, degree_a);
    a.addTerm(456, 78);
    a.addTerm(68, 78);
    a.addTerm(1, 0);

    b.addTerm(2, degree_b);
    b.addTerm(209, degree_b);
    b.addTerm(1, 0);

    Polynomial c = a.multiply(b);

    assertEquals("110564x^300078+211x^300002+211x^300000+524x^78+1x^2+1",
            c.toString());
  }

  /**
   * Tests if a SimplePolynomial and a SparsePolynomial with the same terms are considered equal.
   */
  @Test
  public void testSimpleAndSparsePolynomialsAreEqual() {
    Polynomial poly1 = new SimplePolynomial();
    Polynomial poly2 = new SparsePolynomial();

    poly1.addTerm(4, 3);
    poly1.addTerm(2, 1);

    poly2.addTerm(4, 3);
    poly2.addTerm(2, 1);

    assertTrue(poly2.equals(poly1));
  }

  /**
   * Tests if a SimplePolynomial and a SparsePolynomial with different terms are not equal.
   */
  @Test
  public void testSimpleAndSparsePolynomialsDifferentTerms() {
    Polynomial poly1 = new SimplePolynomial();
    Polynomial poly2 = new SparsePolynomial();

    poly1.addTerm(4, 3);
    poly1.addTerm(2, 1);

    poly2.addTerm(4, 3);
    poly2.addTerm(5, 1);

    assertFalse(poly2.equals(poly1));
  }

  /**
   * Tests if two polynomials of different types are not equal.
   */
  @Test
  public void testPolynomialsEqualsDifferentTypes() {
    Polynomial poly1 = new SimplePolynomial();
    Polynomial poly2 = new SparsePolynomial();

    poly1.addTerm(5, 2);
    poly2.addTerm(5, 2);

    assertTrue(poly2.equals(poly1));
  }
}