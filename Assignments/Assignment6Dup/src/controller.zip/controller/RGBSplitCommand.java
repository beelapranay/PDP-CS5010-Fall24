package controller;

import java.io.IOException;

import model.ImageModelInterface;

public class RGBSplitCommand implements Command {
  private final ImageModelInterface model;

  public RGBSplitCommand(ImageModelInterface model) {
    this.model = model;
  }

  @Override
  public void execute(String[] tokens) throws IOException {
    if (tokens.length < 5) {
      System.out.println("Error: 'rgb-split' requires three destination image names.");
    } else {
      try {
        model.applyGreyscaleTransformation(tokens[1], tokens[2],
                "red-component", 100);
        model.applyGreyscaleTransformation(tokens[1], tokens[3],
                "green-component", 100);
        model.applyGreyscaleTransformation(tokens[1], tokens[4],
                "blue-component", 100);
      } catch (Exception e) {
        System.out.println("Error during RGB Split: " + e.getMessage());
      }
    }
  }
}

