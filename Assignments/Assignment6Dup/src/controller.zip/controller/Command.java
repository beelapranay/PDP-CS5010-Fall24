package controller;

import java.io.IOException;

public interface Command {
  void execute(String[] tokens) throws IOException;
}
