package controller;

import java.io.IOException;

import model.ImageModelInterface;

public class RGBCombineCommand implements Command {
  private final ImageModelInterface model;

  public RGBCombineCommand(ImageModelInterface model) {
    this.model = model;
  }

  @Override
  public void execute(String[] tokens) throws IOException {
    if (tokens.length < 5) {
      System.out.println("Error: 'rgb-combine' requires three source "
              + "and one destination image names.");
    } else {
      try {
        model.combineGreyscale(tokens[1], tokens[2], tokens[3], tokens[4]);
      } catch (Exception e) {
        System.out.println("Error during RGB Combine: " + e.getMessage());
      }
    }
  }
}

