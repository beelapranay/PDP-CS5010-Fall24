package controller;

import view.ImageViewInterface;

public class HistogramCommand implements Command {
  private final ImageViewInterface view;

  public HistogramCommand(ImageViewInterface view) {
    this.view = view;
  }

  @Override
  public void execute(String[] tokens) {
    if (tokens.length < 3) {
      System.out.println("Error: 'histogram' requires a source and a destination image name.");
      return;
    }
    try {
      view.generateAndStoreHistogram(tokens[1], tokens[2]);
    } catch (Exception e) {
      System.out.println("Error generating histogram: " + e.getMessage());
    }
  }
}

