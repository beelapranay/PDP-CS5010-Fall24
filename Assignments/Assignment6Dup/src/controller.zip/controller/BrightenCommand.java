package controller;

import java.io.IOException;

import model.ImageModelInterface;

public class BrightenCommand implements Command {
  private final ImageModelInterface model;

  public BrightenCommand(ImageModelInterface model) {
    this.model = model;
  }

  @Override
  public void execute(String[] tokens) throws IOException {
    if (tokens.length < 4) {
      System.out.println("Error: 'brighten' requires a brightness value, source, and destination image names.");
    } else {
      try {
        int brightnessValue = Integer.parseInt(tokens[1]);

        String sourceImageName = tokens[2];
        String destinationImageName = tokens[3];

        model.changeBrightness(sourceImageName, destinationImageName, brightnessValue);
      } catch (NumberFormatException e) {
        System.out.println("Error: Brightness value must be a valid integer.");
      }
    }
  }
}

