package controller;

import java.io.IOException;

public class SaveCommand implements Command {
  private final ImageController controller;

  public SaveCommand(ImageController controller) {
    this.controller = controller;
  }

  @Override
  public void execute(String[] tokens) throws IOException {
    if (tokens.length < 3) {
      System.out.println("Error: 'save' requires a file path and image name.");
    } else {
      controller.saveImage(tokens[1], tokens[2]);
    }
  }
}
