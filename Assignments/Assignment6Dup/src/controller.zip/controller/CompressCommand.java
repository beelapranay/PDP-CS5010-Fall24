package controller;

import java.io.IOException;

import model.ImageModelInterface;

public class CompressCommand implements Command {
  private final ImageModelInterface model;

  public CompressCommand(ImageModelInterface model) {
    this.model = model;
  }

  @Override
  public void execute(String[] tokens) throws IOException {
    if (tokens.length < 4) {
      System.out.println("Error: 'compress' requires a compression percentage, source, and destination image names.");
    } else {
      try {
        int compressionPercentage = Integer.parseInt(tokens[1]);

        if (compressionPercentage < 0 || compressionPercentage > 100) {
          throw new IllegalArgumentException("Compression percentage must be between 0 and 100.");
        }

        model.compressImage(tokens[1], tokens[2], tokens[3]);
      } catch (NumberFormatException e) {
        System.out.println("Error: Compression percentage must be a valid integer.");
      } catch (IllegalArgumentException e) {
        System.out.println("Error: " + e.getMessage());
      }
    }
  }
}