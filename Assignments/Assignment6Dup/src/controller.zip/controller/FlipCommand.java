package controller;

import java.io.IOException;

import model.ImageModelInterface;

public class FlipCommand implements Command {
  private final ImageModelInterface model;

  public FlipCommand(ImageModelInterface model) {
    this.model = model;
  }

  @Override
  public void execute(String[] tokens) throws IOException {
    if (tokens.length < 3) {
      System.out.println("Error: '" + tokens[0]
              + "' requires source and destination image names.");
      return;
    }

    String sourceImageName = tokens[1];
    String destinationImageName = tokens[2];
    String flipType = tokens[0];

    if (!flipType.equals("horizontal-flip") && !flipType.equals("vertical-flip")) {
      System.out.println("Error: Invalid flip operation '" + flipType + "'.");
      return;
    }

    model.flipImage(sourceImageName, destinationImageName, flipType);
  }
}

