package controller;

import java.io.IOException;

import model.ImageModelInterface;

public class GreyscaleCommand implements Command {
  private final ImageModelInterface model;

  public GreyscaleCommand(ImageModelInterface model) {
    this.model = model;
  }

  @Override
  public void execute(String[] tokens) throws IOException {
    if (tokens.length < 3) {
      System.out.println("Error: Greyscale transformation requires source and destination image names.");
      return;
    }

    String sourceImageName = tokens[1];
    String destinationImageName = tokens[2];
    String transformationType = tokens[0];

    if (tokens.length == 3) {
      model.applyGreyscaleTransformation(sourceImageName, destinationImageName,
              transformationType, 100);
    } else if (tokens.length == 5 && tokens[3].equals("split")) {
      try {
        int splitPercentage = Integer.parseInt(tokens[4]);
        if (splitPercentage < 0 || splitPercentage > 100) {
          System.out.println("Error: Split percentage must be between 0 and 100.");
          return;
        }

        model.applyGreyscaleTransformation(sourceImageName, destinationImageName,
                transformationType, splitPercentage);
      } catch (NumberFormatException e) {
        System.out.println("Error: Invalid split percentage. "
                + "Please enter a valid integer between 0 and 100.");
      }
    } else {
      System.out.println("Error: Invalid arguments for " + transformationType + " transformation.");
    }
  }
}
