package controller;

import java.io.IOException;

import model.ImageModelInterface;

public class BlurAndSharpenCommand implements Command {
  private final ImageModelInterface model;

  public BlurAndSharpenCommand(ImageModelInterface model) {
    this.model = model;
  }

  @Override
  public void execute(String[] tokens) throws IOException {
    if (tokens.length == 3) {
      model.blurOrSharpen(tokens[1], tokens[2], 100, tokens[0]);
    } else if (tokens.length == 5 && tokens[3].equals("split")) {
      try {
        int splitPercentage = Integer.parseInt(tokens[4]);

        if (splitPercentage < 0 || splitPercentage > 100) {
          throw new IllegalArgumentException("Split percentage must be between 0 and 100.");
        }

        model.blurOrSharpen(tokens[1], tokens[2], splitPercentage, tokens[0]);
      } catch (NumberFormatException e) {
        System.out.println("Error: Split percentage must be a valid integer.");
      } catch (IllegalArgumentException e) {
        System.out.println("Error: " + e.getMessage());
      }
    } else {
      System.out.println("Error: Invalid arguments for " + tokens[0]);
    }
  }
}