package controller;

import java.io.IOException;

public class LoadCommand implements Command {
  private final ImageController controller;

  public LoadCommand(ImageController controller) {
    this.controller = controller;
  }

  @Override
  public void execute(String[] tokens) throws IOException {
    if (tokens.length < 3) {
      System.out.println("Error: 'load' requires a file path and image name.");
    } else {
      controller.loadImage(tokens[1], tokens[2]);
    }
  }
}
