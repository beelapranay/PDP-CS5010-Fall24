package controller;

public interface GetAndRegisterCommands {
  void register(String commandName, Command command);

  Command get(String commandName);
}
