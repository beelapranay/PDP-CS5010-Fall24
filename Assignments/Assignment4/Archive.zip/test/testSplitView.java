import org.junit.Before;
import org.junit.Test;

import java.io.IOException;

import controller.ImageController;
import model.ImageModel;
import model.ImageModelInterface;
import model.RGB;
import view.ImageViewInterface;

import static org.junit.Assert.assertEquals;

public class testSplitView {

  private ImageController imageController;
  private ImageModelInterface imageModel;
  private ImageViewInterface imageView;
  private String originalImageName;
  private String transformedImageName;
  private int splitPercentage;

  /**
   * Set up the model and controller for the tests.
   */
  @Before
  public void setUp() throws IOException {
    imageController = new ImageController();

    imageModel = new ImageModel(imageController, imageView);
    originalImageName = "testImage";
    transformedImageName = "transformedImage";
    splitPercentage = 50;
    imageController.loadImage("resources/testImages/jpg/earth.jpg", originalImageName);
  }

  @Test
  public void testApplySepiaToneWithSplit() {
    imageModel.applySepiaTone(originalImageName, transformedImageName, splitPercentage);

    RGB[][] originalPixels = imageController.getImages().get(originalImageName);
    RGB[][] sepiaPixels = imageController.getImages().get(transformedImageName);

    int width = originalPixels[0].length;
    int expectedSplitPoint = (int) (width * (splitPercentage / 100.0));

    for (int y = 0; y < originalPixels.length; y++) {
      for (int x = 0; x < expectedSplitPoint; x++) {
        RGB originalPixel = originalPixels[y][x];
        RGB sepiaPixel = sepiaPixels[y][x];

        int expectedRed = (int) Math.min(0.393 * originalPixel.red
                + 0.769 * originalPixel.green + 0.189 * originalPixel.blue, 255);
        int expectedGreen = (int) Math.min(0.349 * originalPixel.red
                + 0.686 * originalPixel.green + 0.168 * originalPixel.blue, 255);
        int expectedBlue = (int) Math.min(0.272 * originalPixel.red
                + 0.534 * originalPixel.green + 0.131 * originalPixel.blue, 255);

        assertEquals(expectedRed, sepiaPixel.red);
        assertEquals( expectedGreen, sepiaPixel.green);
        assertEquals(expectedBlue, sepiaPixel.blue);
      }
    }

    for (int y = 0; y < originalPixels.length; y++) {
      for (int x = expectedSplitPoint; x < width; x++) {
        RGB originalPixel = originalPixels[y][x];
        RGB sepiaPixel = sepiaPixels[y][x];

        assertEquals(originalPixel.red, sepiaPixel.red);
        assertEquals( originalPixel.green, sepiaPixel.green);
        assertEquals(originalPixel.blue, sepiaPixel.blue);
      }
    }
  }

  @Test
  public void testApplyBlurWithSplit() {
    imageModel.blurOrSharpen(originalImageName, transformedImageName,
            splitPercentage, "blur");

    RGB[][] originalPixels = imageController.getImages().get(originalImageName);
    RGB[][] blurredPixels = imageController.getImages().get(transformedImageName);

    int width = originalPixels[0].length;
    int height = originalPixels.length;
    int expectedSplitPoint = (int) (width * (splitPercentage / 100.0));

    double[][] blurKernel = new double[][]{
            {1.0 / 16, 1.0 / 8, 1.0 / 16},
            {1.0 / 8, 1.0 / 4, 1.0 / 8},
            {1.0 / 16, 1.0 / 8, 1.0 / 16}
    };

    for (int y = 1; y < height - 1; y++) {
      for (int x = 1; x < expectedSplitPoint; x++) {
        double expectedRed = 0;
        double expectedGreen = 0;
        double expectedBlue = 0;

        for (int ky = -1; ky <= 1; ky++) {
          for (int kx = -1; kx <= 1; kx++) {
            RGB neighbor = originalPixels[y + ky][x + kx];
            expectedRed += neighbor.red * blurKernel[ky + 1][kx + 1];
            expectedGreen += neighbor.green * blurKernel[ky + 1][kx + 1];
            expectedBlue += neighbor.blue * blurKernel[ky + 1][kx + 1];
          }
        }

        RGB blurredPixel = blurredPixels[y][x];
        assertEquals("Blurred red mismatch at (" + y + ", " + x + ")",
                (int) Math.min(Math.max(expectedRed, 0), 255), blurredPixel.red);
        assertEquals("Blurred green mismatch at (" + y + ", " + x + ")",
                (int) Math.min(Math.max(expectedGreen, 0), 255), blurredPixel.green);
        assertEquals("Blurred blue mismatch at (" + y + ", " + x + ")",
                (int) Math.min(Math.max(expectedBlue, 0), 255), blurredPixel.blue);
      }
    }
  }

  @Test
  public void testApplySharpenWithSplit() {
    imageModel.blurOrSharpen(originalImageName, transformedImageName,
            splitPercentage, "sharpen");

    RGB[][] originalPixels = imageController.getImages().get(originalImageName);
    RGB[][] sharpenedPixels = imageController.getImages().get(transformedImageName);

    int width = originalPixels[0].length;
    int height = originalPixels.length;
    int expectedSplitPoint = (int) (width * (splitPercentage / 100.0));

    final double[][] sharpenKernel = {
            {-1.0 / 8, -1.0 / 8, -1.0 / 8, -1.0 / 8, -1.0 / 8},
            {-1.0 / 8, 1.0 / 4, 1.0 / 4, 1.0 / 4, -1.0 / 8},
            {-1.0 / 8, 1.0 / 4, 1.0, 1.0 / 4, -1.0 / 8},
            {-1.0 / 8, 1.0 / 4, 1.0 / 4, 1.0 / 4, -1.0 / 8},
            {-1.0 / 8, -1.0 / 8, -1.0 / 8, -1.0 / 8, -1.0 / 8}
    };

    for (int y = 2; y < height - 2; y++) {
      for (int x = 2; x < expectedSplitPoint; x++) {
        double expectedRed = 0;
        double expectedGreen = 0;
        double expectedBlue = 0;

        for (int ky = -2; ky <= 2; ky++) {
          for (int kx = -2; kx <= 2; kx++) {
            RGB neighbor = originalPixels[y + ky][x + kx];
            expectedRed += neighbor.red * sharpenKernel[ky + 2][kx + 2];
            expectedGreen += neighbor.green * sharpenKernel[ky + 2][kx + 2];
            expectedBlue += neighbor.blue * sharpenKernel[ky + 2][kx + 2];
          }
        }

        RGB sharpenedPixel = sharpenedPixels[y][x];
        assertEquals((int) Math.min(Math.max(expectedRed, 0), 255), sharpenedPixel.red);
        assertEquals((int) Math.min(Math.max(expectedGreen, 0), 255), sharpenedPixel.green);
        assertEquals((int) Math.min(Math.max(expectedBlue, 0), 255), sharpenedPixel.blue);
      }
    }

  }
}
