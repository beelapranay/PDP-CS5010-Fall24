import org.junit.Before;
import org.junit.Test;

import java.io.IOException;

import controller.ImageController;
import model.ImageModel;
import model.ImageModelInterface;
import model.RGB;
import view.ImageView;
import view.ImageViewInterface;

import static org.junit.Assert.assertTrue;

public class ImageCompressionTest {
  ImageController imageController;
  ImageModelInterface imageModel;
  ImageViewInterface imageView;

  /**
   * Set up the model and controller for the tests.
   */
  @Before
  public void setUp() {
    imageController = new ImageController();
    imageView = new ImageView(imageController);
    imageModel = new ImageModel(imageController, imageView);
  }

//  @Test
//  public void testPixelDifferenceAfterCompression() throws IOException {
//    String originalImageName = "earth";
//    String compressedImageName = "earthCompressed";
//
//    // Load an original image
//    imageController.loadImage("resources/testImages/jpg/unnamed.jpg", originalImageName);
//
//    // Compress the image
//    imageModel.compressImage("95", originalImageName, compressedImageName);
//
//    RGB[][] originalPixels = imageController.getImages().get(originalImageName);
//    RGB[][] compressedPixels = imageController.getImages().get(compressedImageName);
//
//    // Calculate the average pixel difference between original and compressed images
//    double totalDifference = calculateAveragePixelDifference(originalPixels, compressedPixels);
//    System.out.println("Total difference: " + totalDifference);
//
//    // Assert that there is a significant difference due to compression
//    assertTrue("Pixel difference should be noticeable after compression",
//            totalDifference > 10);
//  }
//
//  private double calculateAveragePixelDifference(RGB[][] original, RGB[][] compressed) {
//    int height = original.length;
//    int width = original[0].length;
//    double totalDifference = 0;
//
//    for (int y = 0; y < height; y++) {
//      for (int x = 0; x < width; x++) {
//        totalDifference += Math.abs(original[y][x].red - compressed[y][x].red)
//                + Math.abs(original[y][x].green - compressed[y][x].green)
//                + Math.abs(original[y][x].blue - compressed[y][x].blue);
//      }
//    }
//    return totalDifference / (width * height);  // Average difference per color channel
//  }

  @Test
  public void testHighCompressionJPGImages() throws IOException {
    String originalImageName = "earth";
    String compressedImageName = "earthCompressed";

    // Load an original image
    imageController.loadImage("resources/testImages/jpg/unnamed.jpg", originalImageName);

    imageModel.compressImage("95", originalImageName, compressedImageName);

    RGB[][] originalPixels = imageController.getImages().get(originalImageName);
    RGB[][] compressedPixels = imageController.getImages().get(compressedImageName);

    int originalNonZeroCount = countNonZeroTerms(originalPixels);
    int compressedNonZeroCount = countNonZeroTerms(compressedPixels);

    assertTrue("Compression should reduce the number of non-zero terms",
            compressedNonZeroCount < originalNonZeroCount);
  }

  @Test
  public void testMidCompressionJPGImages() throws IOException {
    String originalImageName = "earth";
    String compressedImageName = "earthCompressed";

    // Load an original image
    imageController.loadImage("resources/testImages/jpg/unnamed.jpg", originalImageName);

    imageModel.compressImage("50", originalImageName, compressedImageName);

    RGB[][] originalPixels = imageController.getImages().get(originalImageName);
    RGB[][] compressedPixels = imageController.getImages().get(compressedImageName);

    int originalNonZeroCount = countNonZeroTerms(originalPixels);
    int compressedNonZeroCount = countNonZeroTerms(compressedPixels);

    assertTrue("Compression should reduce the number of non-zero terms",
            originalNonZeroCount == compressedNonZeroCount);
  }

  @Test
  public void testLowCompressionJPGImages() throws IOException {
    String originalImageName = "earth";
    String compressedImageName = "earthCompressed";

    // Load an original image
    imageController.loadImage("resources/testImages/jpg/unnamed.jpg", originalImageName);

    imageModel.compressImage("20", originalImageName, compressedImageName);

    RGB[][] originalPixels = imageController.getImages().get(originalImageName);
    RGB[][] compressedPixels = imageController.getImages().get(compressedImageName);

    int originalNonZeroCount = countNonZeroTerms(originalPixels);
    int compressedNonZeroCount = countNonZeroTerms(compressedPixels);

    assertTrue("Compression should reduce the number of non-zero terms",
            originalNonZeroCount == compressedNonZeroCount);
  }

  @Test
  public void testHighCompressionPNGImages() throws IOException {
    String originalImageName = "earth";
    String compressedImageName = "earthCompressed";

    // Load an original image
    imageController.loadImage("resources/testImages/png/square.png", originalImageName);

    imageModel.compressImage("95", originalImageName, compressedImageName);

    RGB[][] originalPixels = imageController.getImages().get(originalImageName);
    RGB[][] compressedPixels = imageController.getImages().get(compressedImageName);

    int originalNonZeroCount = countNonZeroTerms(originalPixels);
    int compressedNonZeroCount = countNonZeroTerms(compressedPixels);

    assertTrue(originalNonZeroCount == compressedNonZeroCount);
  }

  @Test
  public void testMidCompressionPNGImages() throws IOException {
    String originalImageName = "earth";
    String compressedImageName = "earthCompressed";

    // Load an original image
    imageController.loadImage("resources/testImages/png/square.png", originalImageName);

    imageModel.compressImage("50", originalImageName, compressedImageName);

    RGB[][] originalPixels = imageController.getImages().get(originalImageName);
    RGB[][] compressedPixels = imageController.getImages().get(compressedImageName);

    int originalNonZeroCount = countNonZeroTerms(originalPixels);
    int compressedNonZeroCount = countNonZeroTerms(compressedPixels);

    assertTrue(originalNonZeroCount == compressedNonZeroCount);
  }

  @Test
  public void testLowCompressionPNGImages() throws IOException {
    String originalImageName = "earth";
    String compressedImageName = "earthCompressed";

    // Load an original image
    imageController.loadImage("resources/testImages/png/square.png", originalImageName);

    imageModel.compressImage("20", originalImageName, compressedImageName);

    RGB[][] originalPixels = imageController.getImages().get(originalImageName);
    RGB[][] compressedPixels = imageController.getImages().get(compressedImageName);

    int originalNonZeroCount = countNonZeroTerms(originalPixels);
    int compressedNonZeroCount = countNonZeroTerms(compressedPixels);

    assertTrue(originalNonZeroCount == compressedNonZeroCount);
  }

  @Test
  public void testHighCompressionPPMImages() throws IOException {
    String originalImageName = "earth";
    String compressedImageName = "earthCompressed";

    // Load an original image
    imageController.loadImage("resources/testImages/ppm/4x4.ppm", originalImageName);

    imageModel.compressImage("95", originalImageName, compressedImageName);

    RGB[][] originalPixels = imageController.getImages().get(originalImageName);
    RGB[][] compressedPixels = imageController.getImages().get(compressedImageName);

    int originalNonZeroCount = countNonZeroTerms(originalPixels);
    int compressedNonZeroCount = countNonZeroTerms(compressedPixels);

    assertTrue(originalNonZeroCount == compressedNonZeroCount);
  }

  @Test
  public void testMidCompressionPPMImages() throws IOException {
    String originalImageName = "earth";
    String compressedImageName = "earthCompressed";

    // Load an original image
    imageController.loadImage("resources/testImages/ppm/4x4.ppm", originalImageName);

    imageModel.compressImage("50", originalImageName, compressedImageName);

    RGB[][] originalPixels = imageController.getImages().get(originalImageName);
    RGB[][] compressedPixels = imageController.getImages().get(compressedImageName);

    int originalNonZeroCount = countNonZeroTerms(originalPixels);
    int compressedNonZeroCount = countNonZeroTerms(compressedPixels);

    assertTrue(originalNonZeroCount == compressedNonZeroCount);
  }

  @Test
  public void testLowCompressionPPMImages() throws IOException {
    String originalImageName = "earth";
    String compressedImageName = "earthCompressed";

    // Load an original image
    imageController.loadImage("resources/testImages/ppm/4x4.ppm", originalImageName);

    imageModel.compressImage("20", originalImageName, compressedImageName);

    RGB[][] originalPixels = imageController.getImages().get(originalImageName);
    RGB[][] compressedPixels = imageController.getImages().get(compressedImageName);

    int originalNonZeroCount = countNonZeroTerms(originalPixels);
    int compressedNonZeroCount = countNonZeroTerms(compressedPixels);

    assertTrue(originalNonZeroCount == compressedNonZeroCount);
  }

  @Test
  public void testSavingCompressedPPMImages() throws IOException {
    String originalImageName = "earth";
    String compressedImageName = "earthCompressed";

    // Load an original image
    imageController.loadImage("resources/testImages/ppm/4x4.ppm", originalImageName);

    imageModel.compressImage("95", originalImageName, compressedImageName);

    imageController.saveImage("resources/res/ppmRes/4x4Compressed.ppm", compressedImageName);
  }

  @Test
  public void testSavingCompressedJPGImages() throws IOException {
    String originalImageName = "earth";
    String compressedImageName = "earthCompressed";

    // Load an original image
    imageController.loadImage("resources/testImages/jpg/unnamed.jpg", originalImageName);

    imageModel.compressImage("99", originalImageName, compressedImageName);

    imageController.saveImage("resources/res/jpgRes/unnamedCompressed.jpg", compressedImageName);
  }


  @Test
  public void testSavingCompressedPNGImages() throws IOException {
    String originalImageName = "earth";
    String compressedImageName = "earthCompressed";

    // Load an original image
    imageController.loadImage("resources/testImages/png/square.png", originalImageName);

    imageModel.compressImage("95", originalImageName, compressedImageName);

    imageController.saveImage("resources/res/pngRes/squareCompressed.png", compressedImageName);
  }


  private int countNonZeroTerms(RGB[][] pixels) {
    int nonZeroCount = 0;
    for (RGB[] row : pixels) {
      for (RGB pixel : row) {
        if (pixel.red != 0 || pixel.green != 0 || pixel.blue != 0) {
          nonZeroCount++;
        }
      }
    }
    return nonZeroCount;
  }
}
