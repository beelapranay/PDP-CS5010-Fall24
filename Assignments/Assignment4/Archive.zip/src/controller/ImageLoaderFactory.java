package controller;

public class ImageLoaderFactory {
  public static ImageLoaderAndSaver getImageLoader(String filePath, ImageControllerInterface imageController) throws UnsupportedOperationException {
    if (filePath.endsWith(".ppm")) {
      return new PPMImageLoaderAndSaver(imageController);
    } else if (filePath.endsWith(".jpg") || filePath.endsWith(".png")) {
      return new DefaultImageLoaderAndSaver(imageController);
    } else {
      throw new UnsupportedOperationException();
    }
  }
}
