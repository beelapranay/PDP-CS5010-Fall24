package controller;

import java.io.IOException;
import java.util.HashMap;

import model.RGB;

public interface ImageControllerInterface {
  void loadImage(String filePath, String imageName) throws IOException;

  void saveImage(String filePath, String imageName) throws IOException;

  HashMap<String, RGB[][]> getImages();

  void commandParser(String command) throws IOException;

  void processCommands(String[] tokens) throws IOException;
}
