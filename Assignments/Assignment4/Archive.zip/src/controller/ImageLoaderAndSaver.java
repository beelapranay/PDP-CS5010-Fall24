package controller;
import java.awt.image.BufferedImage;
import java.io.IOException;

import model.RGB;

public abstract class ImageLoaderAndSaver {

  public abstract RGB[][] loadImage(String filePath, String imageName) throws IOException;

  public abstract void saveImage(String filePath, String imageName) throws IOException;

  protected String getFileFormat(String filePath) {
    String[] parts = filePath.split("\\.");

    if (parts.length > 1) {
      return parts[parts.length - 1];
    } else {
      return "";
    }
  }

  protected BufferedImage arrayToImage(RGB[][] image) {
    int width = image[0].length;
    int height = image.length;

    BufferedImage processedImage = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);

    for (int y = 0; y < height; y++) {
      for (int x = 0; x < width; x++) {
        RGB pixel = image[y][x];

        int rgb = (pixel.red << 16) | (pixel.green << 8) | pixel.blue;

        processedImage.setRGB(x, y, rgb);
      }
    }

    return processedImage;
  }
}