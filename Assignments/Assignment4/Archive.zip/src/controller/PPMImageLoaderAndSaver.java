package controller;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

import model.RGB;

public class PPMImageLoaderAndSaver extends ImageLoaderAndSaver {
  private final ImageControllerInterface imageController;

  public PPMImageLoaderAndSaver(ImageControllerInterface imageController) {
    this.imageController = imageController;
  }

  public RGB[][] loadImage(String filePath, String imageName) throws FileNotFoundException {
    Scanner sc;

    try {
      sc = new Scanner(new FileInputStream(filePath));
    } catch (FileNotFoundException e) {
      System.out.println("File " + filePath + " not found!");
      return null;
    }

    StringBuilder builder = new StringBuilder();
    //read the file line by line, and populate a string. This will throw away any comment lines
    while (sc.hasNextLine()) {
      String s = sc.nextLine();
      if (s.charAt(0) != '#') {
        builder.append(s + System.lineSeparator());
      }
    }

    //now set up the scanner to read from the string we just built
    sc = new Scanner(builder.toString());

    String token;

    token = sc.next();
    if (!token.equals("P3")) {
      System.out.println("Invalid PPM file: plain RAW file should begin with P3");
      return null;
    }

    int width = sc.nextInt();
    int height = sc.nextInt();

    RGB[][] pixelArray = new RGB[height][width];

    for (int i = 0; i < height; i++) {
      for (int j = 0; j < width; j++) {
        int r = sc.nextInt();
        int g = sc.nextInt();
        int b = sc.nextInt();

        pixelArray[i][j] = new RGB(r, g, b);
      }
    }

    System.out.println(">>>>>>>>Printing stored matix");
    // print the matix
    for (int i = 0; i < pixelArray.length; i++) {
      for (int j = 0; j < pixelArray[i].length; j++) {
        System.out.println(pixelArray[i][j].red + " " + pixelArray[i][j].green + " " + pixelArray[i][j].blue);
      }
    }

//    System.out.println(">>>>>>>>Check if the image is stored");
//    System.out.println(images.containsKey(imageName));

    return pixelArray;
  }

  @Override
  public void saveImage(String filePath, String imageName) throws IOException {
    RGB[][] pixelArray = this.imageController.getImages().get(imageName);

    try {
      int width = pixelArray[0].length;
      int height = pixelArray.length;

      // Create a FileWriter to write to the .ppm file
      FileWriter writer = new FileWriter(filePath);

      // Step 1: Write the PPM header
      writer.write("P3\n");                   // Magic number for PPM (plain text)
      writer.write(width + " " + height + "\n"); // Image width and height
      writer.write("255\n");                 // Maximum color value (255 for RGB)

      // Step 2: Write the pixel data
      for (int y = 0; y < height; y++) {
        for (int x = 0; x < width; x++) {
          RGB pixel = pixelArray[y][x];

          // Write each pixel's R, G, B values
          writer.write(pixel.red + " " + pixel.green + " " + pixel.blue + " ");
        }
        writer.write("\n"); // Newline after each row
      }

      // Close the writer
      writer.close();
    } catch (IOException e) {
      throw new IOException();
    }
  }
}
