package controller;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

import model.RGB;

public class DefaultImageLoaderAndSaver extends ImageLoaderAndSaver {
  private final ImageControllerInterface imageController;

  public DefaultImageLoaderAndSaver(ImageControllerInterface imageController) {
    this.imageController = imageController;
  }

  @Override
  public RGB[][] loadImage(String filePath, String imageName) throws IOException {
    RGB[][] pixelArray;

    try {
      BufferedImage image = ImageIO.read(new File(filePath));

      int width = image.getWidth();
      int height = image.getHeight();

      pixelArray = new RGB[height][width];

      for (int y = 0; y < height; y++) {
        for (int x = 0; x < width; x++) {
          int rgb = image.getRGB(x, y);

          int red = (rgb >> 16) & 0xFF;
          int green = (rgb >> 8) & 0xFF;
          int blue = rgb & 0xFF;

          pixelArray[y][x] = new RGB(red, green, blue);
        }
      }
    } catch (IOException e) {
      System.out.println("Error loading image " + e.getMessage());
      throw new IOException(e);
    }

    return pixelArray;
  }

  public void saveImage(String filePath, String imageName) throws IOException {
    try {
      File outputfile = new File(filePath);

      ImageIO.write(arrayToImage(this.imageController.getImages().get(imageName)),
              getFileFormat(filePath),
              outputfile);
    } catch (IOException e) {
      throw new IOException(e.getMessage());
    }
  }

}
