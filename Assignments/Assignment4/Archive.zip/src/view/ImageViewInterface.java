package view;

import java.util.Map;

import model.RGB;

public interface ImageViewInterface {
  void generateAndStoreHistogram(String imageName, String destinationImageName);

  Map<String, int[]> calculateHistogramData(RGB[][] pixelArray);
}

