package model;

/**
 * Marker interface for RGB class.
 * Empty interface for better design, implemented by RGB class.
 */
public interface RGBInterface {

}
