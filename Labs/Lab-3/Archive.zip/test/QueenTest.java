import solution.ChessPiece;
import solution.Color;
import solution.Queen;

public class QueenTest extends ChessPiecesTest{
  @Override
  protected ChessPiece chessPiece(int row, int col, Color color) {
    return new Queen(row, col, color);
  }

  @Override
  protected void setupResults(int row, int col) {

    for (int i = 0; i < 8; i++) {
      results[i][col] = true;
      results[row][i] = true;
      if ((row + i) < 8) {
        if ((col + i) < 8) {
          results[row + i][col + i] = true;
        }
        if (col >= i) {
          results[row + i][col - i] = true;
        }

      }

      if (row >= i) {
        if ((col + i) < 8) {
          results[row - i][col + i] = true;
        }
        if (col >= i) {
          results[row - i][col - i] = true;
        }
      }
    }

  }
}
