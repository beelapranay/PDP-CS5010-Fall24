import solution.ChessPiece;
import solution.Color;
import solution.Knight;

public class KnightTest extends ChessPiecesTest{
  @Override
  protected ChessPiece chessPiece(int row, int col, Color color) {
    return new Knight(row, col, color);
  }

  @Override
  protected void setupResults(int row, int col) {
    //check if canMove works
    int[][] knightMoves = {
            {2, 1}, {2, -1}, {-2, 1}, {-2, -1},
            {1, 2}, {1, -2}, {-1, 2}, {-1, -2}
    };

    for (int[] move : knightMoves) {
      int newRow = row + move[0];
      int newCol = col + move[1];

      // Ensure the new position is within the 8x8 board bounds
      if (newRow >= 0 && newRow < 8 && newCol >= 0 && newCol < 8) {
        results[newRow][newCol] = true;
      }
    }
  }
}
