import solution.ChessPiece;
import solution.Color;
import solution.Rook;

public class RookTest extends ChessPiecesTest{
  @Override
  protected ChessPiece chessPiece(int row, int col, Color color) {
    return new Rook(row, col, color);
  }

  @Override
  protected void setupResults(int row, int col) {
    //check if canMove works
    for (int i = 0; i < 8; i++) {
      results[i][col] = true;
      results[row][i] = true;
    }
  }
}
