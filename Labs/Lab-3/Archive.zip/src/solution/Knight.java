package solution;

public class Knight extends MovesAbstractClass {
  public Knight(int row, int col, Color color) throws IllegalArgumentException {
    super(row, col, color);
  }

  @Override
  public boolean canMove(int row, int col) {
    if(!checkForValidMovement(row, col)) {
      return false;
    }


    return (Math.abs(this.row - row) == 2 && Math.abs(this.col - col) == 1)
            || (Math.abs(this.row - row) == 1 && Math.abs(this.col - col) == 2);
  }
}
