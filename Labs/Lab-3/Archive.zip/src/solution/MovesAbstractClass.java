package solution;

public abstract class MovesAbstractClass implements ChessPiece {
  protected int row;
  protected int col;
  protected Color color;

  public MovesAbstractClass(int row, int col, Color color) {
    if (row < 0 || col < 0 || row >= 8 || col >= 8) {
      throw new IllegalArgumentException("Invalid position");
    }
    this.row = row;
    this.col = col;
    this.color = color;
  }

  @Override
  public int getRow() {
    return row;
  }

  @Override
  public int getColumn() {
    return col;
  }

  @Override
  public Color getColor() {
    return color;
  }

  protected boolean checkForValidMovement(int row, int col) {
    return (row >= 0) && (col >= 0) && (row < 8) && (col < 8);
  }

  @Override
  public abstract boolean canMove(int row, int col);

  @Override
  public boolean canKill(ChessPiece piece) {
    return (this.getColor() != piece.getColor()) && canMove(
            piece.getRow(),
            piece.getColumn());
  }
}
