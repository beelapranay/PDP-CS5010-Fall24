package solution;

public class Bishop extends MovesAbstractClass {
  public Bishop(int row, int col, Color color) throws IllegalArgumentException {
    super(row, col, color);
  }

  @Override
  public boolean canMove(int row, int col) {
    if(!checkForValidMovement(row, col)) {
      return false;
    }

    return (Math.abs(this.row - row) == Math.abs(this.col - col));
  }
}
