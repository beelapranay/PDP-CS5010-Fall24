package solution;

public enum Color {
  WHITE, BLACK
}
