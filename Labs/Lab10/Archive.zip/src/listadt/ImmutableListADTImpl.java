package listadt;

import java.util.function.Function;

public class ImmutableListADTImpl<T> implements ImmutableListADT<T> {
  private final ListADTImpl<T> internalList;

  private ImmutableListADTImpl(ListADTImpl<T> internalList) {
    this.internalList = internalList;
  }

  public ImmutableListADTImpl() {
    this.internalList = new ListADTImpl<>();
  }

  private ImmutableListADTImpl<T> addBack(T element) {
    ListADTImpl<T> newList = new ListADTImpl<>();
    for (int i = 0; i < internalList.getSize(); i++) {
      newList.addBack(internalList.get(i));
    }
    newList.addBack(element);
    return new ImmutableListADTImpl<>(newList);
  }

  @Override
  public int getSize() {
    return internalList.getSize();
  }

  @Override
  public T get(int index) throws IllegalArgumentException {
    return internalList.get(index);
  }

  @Override
  public <R> ImmutableListADTImpl<R> map(Function<T, R> converter) {
    Builder<R> builder = new Builder<>();
    for (int i = 0; i < internalList.getSize(); i++) {
      builder.addBack(converter.apply(internalList.get(i)));
    }
    return builder.build();
  }

  @Override
  public MutableListADT<T> getMutableList() {
    throw new UnsupportedOperationException("This list is immutable");
  }

  @Override
  public String toString() {
    return internalList.toString();
  }

  public static class Builder<T> {
    private final ListADTImpl<T> tempInternalList;

    public Builder() {
      this.tempInternalList = new ListADTImpl<>();
    }

    public Builder<T> addBack(T element) {
      tempInternalList.addBack(element);
      return this;
    }

    public ImmutableListADTImpl<T> build() {
      return new ImmutableListADTImpl<>(tempInternalList);
    }
  }
}