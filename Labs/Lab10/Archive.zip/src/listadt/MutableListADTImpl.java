package listadt;

import java.util.function.Function;

public class MutableListADTImpl<T> implements MutableListADT<T> {
  private final ListADTImpl<T> internalList;

  public MutableListADTImpl() {
    this.internalList = new ListADTImpl<>();
  }

  @Override
  public ImmutableListADT<T> getImmutableList() {
    ImmutableListADTImpl.Builder<T> builder = new ImmutableListADTImpl.Builder<>();
    for (int i = 0; i < internalList.getSize(); i++) {
      builder.addBack(internalList.get(i));
    }
    return builder.build();
  }

  @Override
  public void addFront(T element) {
    internalList.addFront(element);
  }

  @Override
  public void addBack(T element) {
    internalList.addBack(element);
  }

  @Override
  public void add(int index, T element) {
    internalList.add(index, element);
  }

  @Override
  public void remove(T element) {
    internalList.remove(element);
  }

  @Override
  public <R> MutableListADT<R> map(Function<T, R> converter) {
    ListADTImpl<R> mappedList = (ListADTImpl<R>) internalList.map(converter);
    return new MutableListADTImpl<>(mappedList);
  }

  @Override
  public int getSize() {
    return internalList.getSize();
  }

  @Override
  public T get(int index) throws IllegalArgumentException {
    return internalList.get(index);
  }

  private <R> MutableListADTImpl(ListADTImpl<R> internalList) {
    this.internalList = (ListADTImpl<T>) internalList;
  }

  @Override
  public String toString() {
    return internalList.toString();
  }
}