package spreadsheet;

import java.util.List;

public class MockSpreadSheet implements SpreadSheet {
  private final List<String> log;

  public MockSpreadSheet(List<String> log) {
    this.log = log;
  }

  @Override
  public double get(int row, int col) throws IllegalArgumentException {
    log.add("get(" + row + ", " + col + ")");
    return 0; // Return a dummy value for testing purposes
  }

  @Override
  public void set(int row, int col, double value) throws IllegalArgumentException {
    log.add("set(" + row + ", " + col + ", " + value + ")");
  }

  @Override
  public boolean isEmpty(int row, int col) throws IllegalArgumentException {
    log.add("isEmpty(" + row + ", " + col + ")");
    return true; // Assume the cell is empty for simplicity
  }

  @Override
  public int getWidth() {
    log.add("getWidth()");
    return 0; // Return a default width for testing
  }

  @Override
  public int getHeight() {
    log.add("getHeight()");
    return 0; // Return a default height for testing
  }
}