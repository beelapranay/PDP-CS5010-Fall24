package spreadsheet;

public class ExtendedSparseSpreadSheet extends SparseSpreadSheet implements BetterSpreadSheet {
  @Override
  public void setRegion(int startRow, int startCol, int endRow, int endCol, double value)
          throws IllegalArgumentException {
    if (startRow < 0 || startCol < 0 || endRow < 0 || endCol < 0) {
      throw new IllegalArgumentException("Row and column indices cannot be negative.");
    }
    if (startRow > endRow || startCol > endCol) {
      throw new IllegalArgumentException("Invalid region: start indices " +
              "should be less than or equal to end indices.");
    }

    for (int row = startRow; row <= endRow; row++) {
      for (int col = startCol; col <= endCol; col++) {
        set(row, col, value); // reuse the `set` method from SparseSpreadSheet
      }
    }
  }
}
