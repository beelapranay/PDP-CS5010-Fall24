package spreadsheet;

import java.util.List;

public class MockBetterSpreadSheet implements BetterSpreadSheet {
  private final List<String> log;

  public MockBetterSpreadSheet(List<String> log) {
    this.log = log;
  }

  @Override
  public void setRegion(int startRow, int startCol, int endRow, int endCol, double value) {
    log.add("setRegion(" + startRow + ", " + startCol + ", " + endRow + ", "
            + endCol + ", " + value + ")");
  }

  @Override
  public double get(int row, int col) {
    log.add("get(" + row + ", " + col + ")");
    return 0;
  }

  @Override
  public void set(int row, int col, double value) {
    log.add("set(" + row + ", " + col + ", " + value + ")");
  }

  @Override
  public boolean isEmpty(int row, int col) {
    log.add("isEmpty(" + row + ", " + col + ")");
    return true;
  }

  @Override
  public int getWidth() {
    log.add("getWidth()");
    return 0;
  }

  @Override
  public int getHeight() {
    log.add("getHeight()");
    return 0;
  }
}