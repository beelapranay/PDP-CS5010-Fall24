import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class SingleBloodPressureRecordTest {

  @Test(expected = IllegalArgumentException.class)
  public void testConstructorInvalidID() {
    new SingleBloodPressureRecord(null, 120, 80);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testConstructorInvalidSys() {
    new SingleBloodPressureRecord("123", -120, 80);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testConstructorInvalidDias() {
    new SingleBloodPressureRecord("123", 120, -80);
  }

  @Test
  public void testConstructorValidInput() {
    SingleBloodPressureRecord record = new SingleBloodPressureRecord("123", 120, 80);
    assertEquals("123", record.getID());
    assertEquals(120, record.getSystolicReading(), 0.01);
    assertEquals(80, record.getDiastolicReading(), 0.01);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testUpdateSystolicInvalid() {
    SingleBloodPressureRecord record = new SingleBloodPressureRecord("123", 120, 80);
    record.updateSystolicReading(70); // systolic < diastolic
  }

  @Test
  public void testUpdateSystolicValid() {
    SingleBloodPressureRecord record = new SingleBloodPressureRecord("123", 120, 80);
    record.updateSystolicReading(130);
    assertEquals(130, record.getSystolicReading(), 0.01);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testUpdateDiastolicInvalid() {
    SingleBloodPressureRecord record = new SingleBloodPressureRecord("123", 120, 80);
    record.updateDiastolicReading(130); // diastolic > systolic
  }

  @Test
  public void testUpdateDiastolicValid() {
    SingleBloodPressureRecord record = new SingleBloodPressureRecord("123", 120, 80);
    record.updateDiastolicReading(70);
    assertEquals(70, record.getDiastolicReading(), 0.01);
  }

  @Test
  public void testEqualsSameObject() {
    SingleBloodPressureRecord record1 = new SingleBloodPressureRecord("123", 120, 80);
    assertTrue(record1.equals(record1));
  }

  @Test
  public void testEqualsDifferentObjectSameValues() {
    SingleBloodPressureRecord record1 = new SingleBloodPressureRecord("123", 120, 80);
    SingleBloodPressureRecord record2 = new SingleBloodPressureRecord("123", 120, 80);
    assertTrue(record1.equals(record2));
  }

  @Test
  public void testEqualsDifferentObjectDifferentValues() {
    SingleBloodPressureRecord record1 = new SingleBloodPressureRecord("123", 120, 80);
    SingleBloodPressureRecord record2 = new SingleBloodPressureRecord("123", 130, 90);
    assertFalse(record1.equals(record2));
  }

  @Test
  public void testHashCode() {
    SingleBloodPressureRecord record1 = new SingleBloodPressureRecord("123", 120, 80);
    SingleBloodPressureRecord record2 = new SingleBloodPressureRecord("123", 120, 80);
    assertEquals(record1.hashCode(), record2.hashCode());
  }

}
