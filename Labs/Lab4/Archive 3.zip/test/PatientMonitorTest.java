import org.junit.Test;
import org.junit.Before;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class PatientMonitorTest {

  private PatientMonitor monitor;
  private BloodPressureRecord record1;
  private BloodPressureRecord record2;
  private BloodPressureRecord record3;

  @Before
  public void setup() {
    monitor = new PatientMonitor();
    record1 = new SingleBloodPressureRecord("123", 200, 300);
    record2 = new SingleBloodPressureRecord("456", 190, 130);
    record3 = new SingleBloodPressureRecord("789", 175, 115);
  }

  @Test
  public void testAddRecords() {
    monitor.add(record1);
    monitor.add(record2);
    assertEquals(2, monitor.getNumberOfRecords());
  }

  @Test
  public void testRemoveRecord() {
    monitor.add(record1);
    monitor.add(record2);
    monitor.remove(record1);
    assertEquals(1, monitor.getNumberOfRecords());
  }

  @Test
  public void testEmptyMonitor() {
    assertEquals(0, monitor.getNumberOfRecords());
  }

  @Test
  public void testEmergencyNotTriggered() {
    monitor.add(record1);
    monitor.add(record3);
    assertFalse(monitor.emergency());
  }

  @Test
  public void testEmergencyTriggered() {
    monitor.add(record1);
    monitor.add(record2);
    monitor.add(record3);
    assertTrue(monitor.emergency());
  }

  @Test
  public void testEmergencyWithSameID() {
    BloodPressureRecord record4 = new SingleBloodPressureRecord("123", 200, 130);
    monitor.add(record1);
    monitor.add(record4);
    assertFalse(monitor.emergency());
  }

  @Test
  public void testEmergencyOnlyOncePerID() {
    monitor.add(record1);  // Not critical
    BloodPressureRecord criticalRecord1 = new SingleBloodPressureRecord("123", 200, 130);
    BloodPressureRecord criticalRecord2 = new SingleBloodPressureRecord("456", 190, 130);
    monitor.add(criticalRecord1);
    monitor.add(criticalRecord2);
    assertTrue(monitor.emergency());
  }

}
