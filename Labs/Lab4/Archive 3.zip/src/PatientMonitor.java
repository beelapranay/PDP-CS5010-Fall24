import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * This class represents a patient monitor. It monitor several blood pressure records,
 * specifically to see how many of them are going into hypertensive crisis.
 */

public class PatientMonitor implements Monitor {
  private List<BloodPressureRecord> bpRecordList;
  public Set<String> countedIds;

  public PatientMonitor() {
    this.bpRecordList = new ArrayList<BloodPressureRecord>();
  }

  public void add(BloodPressureRecord t) {
    bpRecordList.add(t);
  }

  public void remove(BloodPressureRecord t) {
    bpRecordList.remove(t);
  }

  public int getNumberOfRecords() {
    return bpRecordList.size();
  }

  public boolean emergency() {
    countedIds = new HashSet<String>();


    for (BloodPressureRecord t: bpRecordList) {
      if(countedIds.contains(t.getID())) {
        continue;
      } else if((t.getSystolicReading() > 180 || t.getDiastolicReading() > 120)) {
        countedIds.add(t.getID());
      }
    }

    for(String id: countedIds) {
      System.out.println(id);
    }
    System.out.println(countedIds.size());

    return countedIds.size() > 1;
  }

}
