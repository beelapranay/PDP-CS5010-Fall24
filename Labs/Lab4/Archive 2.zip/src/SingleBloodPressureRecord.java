import java.util.Objects;

public class SingleBloodPressureRecord implements BloodPressureRecord{
  private String id;
  private double sys;
  private double dias;

  public SingleBloodPressureRecord(String id, double sys, double dias) throws IllegalArgumentException {
    if(id == null || id.isEmpty() || sys < 0 || dias < 0) {
      throw new IllegalArgumentException();
    } else {
      this.id = id;
      this.sys = sys;
      this.dias = dias;
    }
  }

  @Override
  public String getID() {
    return this.id;
  }

  @Override
  public double getSystolicReading() {
    return this.sys;
  }

  @Override
  public double getDiastolicReading() {
    return this.dias;
  }

  @Override
  public void updateSystolicReading(double sys) throws IllegalArgumentException {
    if(sys < this.getDiastolicReading()) {
      throw new IllegalArgumentException();
    } else {
      this.sys = sys;
    }
  }

  @Override
  public void updateDiastolicReading(double dias) throws IllegalArgumentException {
    if(dias > this.getSystolicReading()) {
      throw new IllegalArgumentException();
    } else {
      this.dias = dias;
    }
  }

//  @Override
//  public boolean equals(Object o) {
//    if(o == this) {
//      return true;
//    }
//
//    if(!(o instanceof SingleBloodPressureRecord)) {
//      return false;
//    }
//
//    SingleBloodPressureRecord other = (SingleBloodPressureRecord) o;
//
//    return other.getID().equals(this.id)
//            && this.getSystolicReading()-other.getDiastolicReading() < 1
//            && this.getDiastolicReading()-other.getDiastolicReading() < 1;
//  }

    @Override
  public boolean equals(Object o) {
    if(o == this) {
      return true;
    }

    if(!(o instanceof SingleBloodPressureRecord)) {
      return false;
    }

    SingleBloodPressureRecord other = (SingleBloodPressureRecord) o;

    return other.getID().equals(this.id)
            && Math.round(this.getSystolicReading()) == Math.round(other.getSystolicReading())
            && Math.round(this.getDiastolicReading()) == Math.round(other.getDiastolicReading());
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, sys, dias);
  }
}
