public interface Monitor {
  void add(BloodPressureRecord bpr);

  void remove(BloodPressureRecord bpr);

  int getNumberOfRecords();

  boolean emergency();
}
