public interface Money {
  Money add(Money other);

  Money add(int dollars, int cents) throws IllegalArgumentException;

  double getDecimalValue();
}
