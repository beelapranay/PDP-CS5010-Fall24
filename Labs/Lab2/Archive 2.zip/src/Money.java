public interface Money {
  /**
   * @param other The Money object to be added to this Money object.
   * @return This Money object after addition.
   */
  Money add(Money other);

  /**
   * @param dollars The amount of dollars to be added.
   * @param cents   The amount of cents to be added.
   * @return This Money object after the addition.
   * @throws IllegalArgumentException If either the dollars or cents are negative.
   */
  Money add(int dollars, int cents) throws IllegalArgumentException;

  /**
   * @return The decimal representation of this Money object.
   */
  double getDecimalValue();
}
