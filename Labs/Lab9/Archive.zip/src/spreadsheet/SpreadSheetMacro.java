package spreadsheet;

public interface SpreadSheetMacro {
  void execute(SpreadSheet spreadsheet);
}
