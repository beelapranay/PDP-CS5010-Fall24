package spreadsheet;

public class BulkAssignMacro implements SpreadSheetMacro {
  private final int fromRow;
  private final int fromCol;
  private final int toRow;
  private final int toCol;
  private final double value;

  public BulkAssignMacro(int fromRow, int fromCol, int toRow, int toCol, double value) {
    if (fromRow < 0 || fromCol < 0 || toRow < 0 || toCol < 0) {
      throw new IllegalArgumentException("Row and column numbers must be non-negative.");
    }
    this.fromRow = fromRow;
    this.fromCol = fromCol;
    this.toRow = toRow;
    this.toCol = toCol;
    this.value = value;
  }

  @Override
  public void execute(SpreadSheet spreadsheet) {
    for (int row = fromRow; row <= toRow; row++) {
      for (int col = fromCol; col <= toCol; col++) {
        spreadsheet.set(row, col, value);
      }
    }
  }
}
