package spreadsheet;

public class RangeAssignMacro implements SpreadSheetMacro {
  private final int fromRow;
  private final int fromCol;
  private final int toRow;
  private final int toCol;
  private final double startValue;
  private final double increment;

  public RangeAssignMacro(int fromRow, int fromCol, int toRow, int toCol, double startValue,
                          double increment) {
    this.fromRow = fromRow;
    this.fromCol = fromCol;
    this.toRow = toRow;
    this.toCol = toCol;
    this.startValue = startValue;
    this.increment = increment;
  }

  @Override
  public void execute(SpreadSheet spreadsheet) {
    double value = startValue;
    for (int row = fromRow; row <= toRow; row++) {
      for (int col = fromCol; col <= toCol; col++) {
        spreadsheet.set(row, col, value);
        value += increment;
      }
    }
  }
}
