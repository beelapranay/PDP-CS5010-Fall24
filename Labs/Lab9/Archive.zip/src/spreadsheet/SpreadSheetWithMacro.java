package spreadsheet;

public interface SpreadSheetWithMacro extends SpreadSheet {
  void executeMacro(SpreadSheetMacro macro);
}