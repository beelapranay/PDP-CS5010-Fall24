package spreadsheet;

public class SpreadSheetWithMacroImpl implements SpreadSheetWithMacro {
  private final SpreadSheet spreadsheet;

  // Default constructor: Initializes with a SparseSpreadSheet instance
  public SpreadSheetWithMacroImpl() {
    this.spreadsheet = new SparseSpreadSheet();
  }

  // Constructor that accepts any SpreadSheet implementation
  public SpreadSheetWithMacroImpl(SpreadSheet spreadsheet) {
    if (spreadsheet == null) {
      throw new IllegalArgumentException("SpreadSheet instance cannot be null.");
    }
    this.spreadsheet = spreadsheet;
  }

  @Override
  public void executeMacro(SpreadSheetMacro macro) {
    macro.execute(spreadsheet);
  }

  @Override
  public double get(int row, int col) {
    return spreadsheet.get(row, col);
  }

  @Override
  public void set(int row, int col, double value) {
    spreadsheet.set(row, col, value);
  }

  @Override
  public boolean isEmpty(int row, int col) {
    return spreadsheet.isEmpty(row, col);
  }

  @Override
  public int getWidth() {
    return spreadsheet.getWidth();
  }

  @Override
  public int getHeight() {
    return spreadsheet.getHeight();
  }
}
