
public enum Color {
    WHITE, BLACK
}
