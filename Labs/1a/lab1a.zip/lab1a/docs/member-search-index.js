memberSearchIndex =
    [{
        "p": "<Unnamed>",
        "c": "Book",
        "l": "Book(String, Person, float)",
        "url": "%3Cinit%3E(java.lang.String,Person,float)"
    }, {"p": "<Unnamed>", "c": "BookTest", "l": "BookTest()", "url": "%3Cinit%3E()"},
        {"p": "<Unnamed>", "c": "Book", "l": "getAuthor()"},
        {"p": "<Unnamed>", "c": "Person", "l": "getFirstName()"},
        {"p": "<Unnamed>", "c": "Person", "l": "getLastName()"},
        {"p": "<Unnamed>", "c": "Book", "l": "getPrice()"},
        {"p": "<Unnamed>", "c": "Book", "l": "getTitle()"},
        {"p": "<Unnamed>", "c": "Person", "l": "getYearOfBirth()"}, {
        "p": "<Unnamed>",
        "c": "Person",
        "l": "Person(String, String, int)",
        "url": "%3Cinit%3E(java.lang.String,java.lang.String,int)"
    }, {"p": "<Unnamed>", "c": "PersonTest", "l": "PersonTest()", "url": "%3Cinit%3E()"},
        {"p": "<Unnamed>", "c": "BookTest", "l": "setUp()"},
        {"p": "<Unnamed>", "c": "PersonTest", "l": "setUp()"},
        {"p": "<Unnamed>", "c": "BookTest", "l": "testAuthorFirstName()"},
        {"p": "<Unnamed>", "c": "BookTest", "l": "testAuthorLastName()"},
        {"p": "<Unnamed>", "c": "PersonTest", "l": "testFirst()"},
        {"p": "<Unnamed>", "c": "BookTest", "l": "testPrice()"},
        {"p": "<Unnamed>", "c": "PersonTest", "l": "testSecond()"},
        {"p": "<Unnamed>", "c": "BookTest", "l": "testTitle()"},
        {"p": "<Unnamed>", "c": "PersonTest", "l": "testYearOfBirth()"},
        {"p": "<Unnamed>", "c": "BookTest", "l": "testYearPublished()"}]