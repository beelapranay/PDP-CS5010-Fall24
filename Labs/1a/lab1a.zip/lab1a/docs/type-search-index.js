typeSearchIndex =
    [{"l": "All Classes", "url": "allclasses-index.html"}, {"p": "<Unnamed>", "l": "Book"},
        {"p": "<Unnamed>", "l": "BookTest"}, {"p": "<Unnamed>", "l": "Person"},
        {"p": "<Unnamed>", "l": "PersonTest"}]